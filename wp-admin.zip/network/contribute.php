<?php
/**
 * Network Contribute administration panel.
 *
 * @package WordPress
 * @subpackage Multisite
 * @since 6.3.0
 */

/** Load WordPress Administration Bootstrap */
require_once __DIR__ . '/admin.php';

require ABSPATH . 'wp-admin/contribute.php';
